﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A2BalpreetkaurdhillonP2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string num1, num2, num3, num4;

                num1 = textBox1.Text;
                num2 = textBox2.Text;
                num3 = textBox3.Text;
                num4 = textBox4.Text;

                double N1, N2, N3, N4, N5, N6, N7, N8, N9;

                N1 = double.Parse(num1);
                N2 = double.Parse(num2);
                N3 = double.Parse(num3);
                N4 = double.Parse(num4);


                N5= 3.14159;


                N7 = (4.0 / 3) * N5 * N1 * N1 * N1;

                N8 = (N5) * (N1 * N1) * (N2);

                N9 = N3 * N4 * N2;

                if (radioButton1.Checked)
                {
                    label6.Text = N7.ToString();
                    textBox2.Text = ("");
                    textBox3.Text = ("");
                    textBox4.Text = ("");
                }
                else if (radioButton2.Checked)
                {
                    label6.Text = N8.ToString();
                    textBox3.Text = ("");
                    textBox4.Text = ("");

                }
                else if (radioButton3.Checked)
                {
                    label6.Text = N9.ToString();
                    textBox1.Text = ("");
                }

            }
            catch
            {
                MessageBox.Show("Please Enter all Values");
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
